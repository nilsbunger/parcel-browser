# Comps report on 2769 San Marino St, Los Angeles, CA 90006
comps_2769_san_marino_90006 = {
    "RESPONSE_GROUP": {
        "RESPONDING_PARTY": {
            "@_Name": "ATTOM Data Solutions",
            "@_StreetAddress": "505 Technology Drive, Suite 100",
            "@_City": "Irvine",
            "@_State": "CA",
            "@_PostalCode": "92618",
        },
        "RESPONSE": {
            "@ResponseDateTime": "2023-04-16T11:11:36",
            "KEY": {"@_Name": "TransactionId", "@_Value": "7f75e301-6e26-418f-a3bd-5aa4154da217"},
            "RESPONSE_DATA": {
                "PROPERTY_INFORMATION_RESPONSE_ext": {
                    "SUBJECT_PROPERTY_ext": {
                        "PROPERTY": [
                            {
                                "@_StreetAddress": "2769 SAN MARINO ST",
                                "@_City": "LOS ANGELES",
                                "@_State": "CA",
                                "@_PostalCode": "90006",
                                "@PropertyParcelID": "4762838",
                                "@SiteMailAddressSameIndicator": "false",
                                "@StandardUseCode_ext": "RAPT",
                                "@StandardUseDescription_ext": "Apartment",
                                "@PrivacyType_ext": "",
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompSubjectProperty",
                                    "@RecordNumber_ext": "0",
                                    "@MappingVersion_ext": "1",
                                },
                                "MAILING_ADDRESS_ext": {
                                    "@_StreetAddress": "718 PRIMROSE LN",
                                    "@_City": "BENICIA",
                                    "@_State": "CA",
                                    "@_PostalCode": "94510",
                                },
                                "_IDENTIFICATION": {
                                    "@RTPropertyID_ext": "4762838",
                                    "@DQPropertyID_ext": "",
                                    "@CountyFIPSName_ext": "LOS ANGELES",
                                    "@AssessorsParcelIdentifier": "5077-028-025",
                                    "@AssessorsSecondParcelIdentifier": "",
                                    "@LongitudeNumber": "-118.288509",
                                    "@LatitudeNumber": "34.055271",
                                },
                                "SALES_HISTORY": {
                                    "@PropertySalesAmount": "1090000",
                                    "@BuyerUnparsedName_ext": "PETER Y KIM,CECILIA I KIM",
                                    "@RecordedDocumentIdentifier": "0003104323",
                                    "@FullOrPartialTransferValueType_ext": "SALE PRICE (FULL) Full sales price as per documents",
                                    "@MultipleApnIndicator_ext": "N",
                                    "@SellerUnparsedName": "CHUNG,KENNY",
                                    "@PricePerSquareFootAmount": "179.28",
                                    "@PropertySalesDate": "2004-12-01T00:00:00",
                                    "LOANS_ext": {
                                        "@SellerCarrybackindicator": "0",
                                        "LOAN_ext": [
                                            {
                                                "@_Type": "First",
                                                "@TrustDeedDocumentNumber": "3104324",
                                                "@_Amount": "720000",
                                            },
                                            {"@_Type": "SecondConcurrent", "@_Amount": ""},
                                            {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                        ],
                                    },
                                },
                                "_OWNER": {
                                    "@_Name": "PETER Y KIM,CECILIA I KIM",
                                    "@_TypeExt": "0",
                                    "@_Description_ext": "INDIVIDUAL",
                                    "@_SecondaryOwnerName_ext": "CECILIA I KIM",
                                },
                                "_LEGAL_DESCRIPTION": {
                                    "@_Type": "Other",
                                    "@_TextDescription": "BROWN'S RESUB OF PART OF LOT 7 OF THE HOLST TRACT LOT 26",
                                },
                                "SITE": {
                                    "@PropertyZoningCategoryType": "COMMERCIAL",
                                    "@DepthFeetCount": "135",
                                    "@WidthFeetCount": "50",
                                    "@LotSquareFeetCount": "6750.00",
                                },
                                "_TAX": {"@_TotalAssessedValueAmount": "1431720", "@_AssessorMarketValue_ext": ""},
                                "STRUCTURE": {
                                    "@TotalBathroomCount": "8.00",
                                    "@TotalBedroomCount": "16",
                                    "@TotalRoomCount": "",
                                    "@StoriesCount": "1",
                                    "@LivingUnitCount": "8",
                                    "@GrossLivingAreaSquareFeetCount": "6080",
                                    "ATTIC": {"@SquareFeetCount": "0"},
                                    "BASEMENT": {"@SquareFeetCount": "0"},
                                    "LEVELS": {
                                        "LEVEL": [
                                            {"@_Type": "LevelOne", "@SquareFeetCount": ""},
                                            {"@_Type": "LevelTwo", "@SquareFeetCount": ""},
                                            {"@_Type": "LevelThree", "@SquareFeetCount": ""},
                                            {"@_Type": "LevelFour", "@SquareFeetCount": ""},
                                        ]
                                    },
                                    "CAR_STORAGE": {
                                        "CAR_STORAGE_LOCATION": {
                                            "@SquareFeetCount": "",
                                            "@_ParkingSpacesCount": "",
                                            "@_Type": "",
                                            "@_TypeOtherDescription": "",
                                        }
                                    },
                                    "HEATING": {"@_UnitDescription": ""},
                                    "COOLING": {"@_UnitDescription": "YES"},
                                    "EXTERIOR_FEATURE": [
                                        {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        }
                                    ],
                                    "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1987"},
                                    "AMENITY": {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                },
                                "SALES_CONTRACT": {"@_Date": "2004-12-01T00:00:00"},
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "0",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "1",
                                    "@DistanceFromSubjectPropertyMilesCount": "0.39810537125",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "941 S GRAND VIEW ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90006",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.053456",
                                    "@LongitudeNumber": "-118.281909",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "43959377",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-07-27T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "3575000.00",
                                        "@BuyerUnparsedName_ext": "WEST ADAMS APARTMENTS LLC",
                                        "@SellerUnparsedName": "CHUNG, OK SHIN",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "441.35802469136",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0001152264",
                                                    "@_Amount": "1800000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "13.00",
                                        "@TotalBedroomCount": "14",
                                        "@TotalBathroomFullCount_ext": "13",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "2",
                                        "@LivingUnitCount": "12",
                                        "@GrossLivingAreaSquareFeetCount": "8100",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1987"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "Type Not Specified",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "150.00",
                                        "@LotSquareFeetCount": "7500.00",
                                        "@WidthFeetCount": "50.00",
                                        "@PropertyZoningCategoryType": "LAR4",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "3575000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "WEST BONNIE BRAE TRACT LOT 19 BLK B",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "269 S BEVERLY DR # # PMB285",
                                        "@_City": "BEVERLY HILLS",
                                        "@_State": "CA",
                                        "@_PostalCode": "90212",
                                    },
                                    "_OWNER": {"@_Name": "WEST ADAMS APARTMENTS LLC", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "1",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "2",
                                    "@DistanceFromSubjectPropertyMilesCount": "0.41460205098",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "917 S CATALINA ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90006",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.055157",
                                    "@LongitudeNumber": "-118.29575",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "52253555",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-02-18T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "1660000.00",
                                        "@BuyerUnparsedName_ext": "BEST 8 LLC",
                                        "@SellerUnparsedName": "PARK, DAVID",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "417.92547834844",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "10.00",
                                        "@TotalBedroomCount": "10",
                                        "@TotalBathroomFullCount_ext": "10",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "5",
                                        "@GrossLivingAreaSquareFeetCount": "3972",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1988"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "CENTRAL"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "6567.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR4",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "815328",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "HENRY RAGATZ TRACT LOT 5",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "1025 S BERENDO ST OFC # 100",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90006",
                                    },
                                    "_OWNER": {"@_Name": "BEST 8 LLC,", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "2",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "3",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.09590984871",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "402 S BONNIE BRAE ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90057",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.060787",
                                    "@LongitudeNumber": "-118.27056",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154597262",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-05-24T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "2300000.00",
                                        "@BuyerUnparsedName_ext": "402 BB LLC",
                                        "@SellerUnparsedName": "HARDING, TERRY M",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "513.39285714286",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0000557755",
                                                    "@_Amount": "1195000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "8.00",
                                        "@TotalBedroomCount": "10",
                                        "@TotalBathroomFullCount_ext": "8",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "8",
                                        "@GrossLivingAreaSquareFeetCount": "4480",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1981"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "NP"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "6351.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR4",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "282939",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "*TR=SUNSET TRACT*(EX OF STS) LOT 8 BLK D",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "93 FREMONT PL",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90005",
                                    },
                                    "_OWNER": {"@_Name": "402 BB LLC,", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "3",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "4",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.16580555344",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "140 S WESTMORELAND AVE",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.072124",
                                    "@LongitudeNumber": "-118.287546",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154759525",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2023-03-31T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "1995000.00",
                                        "@BuyerUnparsedName_ext": "144 WESTMORELAND LLC",
                                        "@SellerUnparsedName": "140 SOUTH WESTMORELAND LLC",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "476.02004294918",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0000206746",
                                                    "@_Amount": "1150000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "7.00",
                                        "@TotalBedroomCount": "9",
                                        "@TotalBathroomFullCount_ext": "7",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "7",
                                        "@GrossLivingAreaSquareFeetCount": "4191",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1982"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "7916.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "2165414",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "TRACT # 6116 LOT 13",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "8654 WILSHIRE BLVD",
                                        "@_City": "BEVERLY HILLS",
                                        "@_State": "CA",
                                        "@_PostalCode": "90211",
                                    },
                                    "_OWNER": {"@_Name": "144 WESTMORELAND LLC", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "4",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "5",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.16781084179",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "273 S BONNIE BRAE ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90057",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.062611",
                                    "@LongitudeNumber": "-118.270133",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "11938439",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-10-27T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "0.00",
                                        "@BuyerUnparsedName_ext": "KUK, CHI KWONG|DECLARATION OF TRUST",
                                        "@SellerUnparsedName": "IP, HOO KWONG",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "0.00",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0001611198",
                                                    "@_Amount": "650000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": ""},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "9.00",
                                        "@TotalBedroomCount": "14",
                                        "@TotalBathroomFullCount_ext": "9",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "1",
                                        "@LivingUnitCount": "9",
                                        "@GrossLivingAreaSquareFeetCount": "7108",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1989"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "Type Not Specified",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "NP"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "150.00",
                                        "@LotSquareFeetCount": "7499.00",
                                        "@WidthFeetCount": "50.00",
                                        "@PropertyZoningCategoryType": "LAR4",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "1628306",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "HAYS ADD TO SUNSET TRACT LOT 1",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "237 S BONNIE BRAE ST",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90057",
                                    },
                                    "_OWNER": {"@_Name": "CHI KWONG KUK", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "5",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "6",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.24702118558",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "122 N VENDOME ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90026",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.072366",
                                    "@LongitudeNumber": "-118.281526",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "54798038",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-03-31T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "0.00",
                                        "@BuyerUnparsedName_ext": "MASISADO BORROMEO, CARMELITA|MASISADO, CRISELDA|CORAZON AND CONRADO MASISADO LIV TR",
                                        "@SellerUnparsedName": "SABLON MASISADO, CONRADO",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "0.00",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0000359662",
                                                    "@_Amount": "350000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": ""},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "7.00",
                                        "@TotalBedroomCount": "13",
                                        "@TotalBathroomFullCount_ext": "7",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "6",
                                        "@GrossLivingAreaSquareFeetCount": "4804",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1984"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "6000.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LARD1.5",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "920909",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "I N VAN NUYS TRACT LOT 15 BLK E",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "7528 SHILOH WAY",
                                        "@_City": "FONTANA",
                                        "@_State": "CA",
                                        "@_PostalCode": "92336",
                                    },
                                    "_OWNER": {
                                        "@_Name": "CARMELITA MASISADO BORROMEO",
                                        "@_SecondaryOwnerName_ext": "",
                                    },
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "6",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "7",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.27926250452",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "2734 COUNCIL ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90026",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.071585",
                                    "@LongitudeNumber": "-118.277943",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154657692",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-05-04T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "1101000.00",
                                        "@BuyerUnparsedName_ext": "SED DEVELOPMENT LLC|SILVERGATE HOUSING LLC",
                                        "@SellerUnparsedName": "LAU, KAM MING",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "332.12669683258",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "5.00",
                                        "@TotalBedroomCount": "8",
                                        "@TotalBathroomFullCount_ext": "5",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "5",
                                        "@GrossLivingAreaSquareFeetCount": "3315",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1982"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "4807.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LARD1.5",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "354137",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "CABLE ROAD TRACT LOT 9 BLK E",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "8721 SANTA MONICA BLVD # # 339",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90069",
                                    },
                                    "_OWNER": {
                                        "@_Name": "SED DEVELOPMENT LLC, & SILVERGATE",
                                        "@_SecondaryOwnerName_ext": "",
                                    },
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "7",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "8",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.53049765379",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "311 N BERENDO ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.076805",
                                    "@LongitudeNumber": "-118.29477",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "18007131",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-07-26T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "2730000.00",
                                        "@BuyerUnparsedName_ext": "BERENDO MANAGEMENT LLC",
                                        "@SellerUnparsedName": "311 BERENDO LLC",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "317.44186046512",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "9.00",
                                        "@TotalBedroomCount": "18",
                                        "@TotalBathroomFullCount_ext": "9",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "9",
                                        "@GrossLivingAreaSquareFeetCount": "8600",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1997"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "7803.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "2730000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "TRACT # 673 S 24 FT OF LOT 24 AND N 28 FT OF LOT 25",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "PO BOX 691979",
                                        "@_City": "WEST HOLLYWOOD",
                                        "@_State": "CA",
                                        "@_PostalCode": "90069",
                                    },
                                    "_OWNER": {"@_Name": "BERENDO MANAGEMENT LLC", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "8",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "9",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.5306247696",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "314 S MANHATTAN PL",
                                    "@_State": "CA",
                                    "@_PostalCode": "90020",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.06844",
                                    "@LongitudeNumber": "-118.31001",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "24513625",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-07-30T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "1400000.00",
                                        "@BuyerUnparsedName_ext": "HOLLYWOOD CARLTON PROPERTIES LLC",
                                        "@SellerUnparsedName": "PARALLAX PROPERTIES LLC",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "122.61341741111",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "18.00",
                                        "@TotalBedroomCount": "18",
                                        "@TotalBathroomFullCount_ext": "18",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "16",
                                        "@GrossLivingAreaSquareFeetCount": "11418",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1987"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "CENTRAL"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "8651.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR4",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "4195000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "WESTMINSTER SQUARE EX OF ALLEY LOT 18",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "11022 SANTA MONICA BLVD STE # 400",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90025",
                                    },
                                    "_OWNER": {
                                        "@_Name": "HOLLYWOOD CARLTON PROPERTIES LLC",
                                        "@_SecondaryOwnerName_ext": "",
                                    },
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "9",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "10",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.6521791928",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "411 N KENMORE AVE",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.078053",
                                    "@LongitudeNumber": "-118.297273",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "30307585",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-12-27T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "0.00",
                                        "@BuyerUnparsedName_ext": "KENMORE VILLAGE LLC",
                                        "@SellerUnparsedName": "YOONG, SOO LEE",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "0.00",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "8.00",
                                        "@TotalBedroomCount": "16",
                                        "@TotalBathroomFullCount_ext": "8",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "1",
                                        "@LivingUnitCount": "8",
                                        "@GrossLivingAreaSquareFeetCount": "7376",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1989"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "Type Not Specified",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "CENTRAL"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "105.00",
                                        "@LotSquareFeetCount": "6930.00",
                                        "@WidthFeetCount": "66.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "3110000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "VISTA DEL MONTE TRACT LOT 10 BLK 1",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "1100 S HOPE ST APT # 1805",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90015",
                                    },
                                    "_OWNER": {"@_Name": "KENMORE VILLAGE LLC,", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "10",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "11",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.65895257022",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "2370 PORTLAND ST",
                                    "@_State": "CA",
                                    "@_PostalCode": "90007",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.031917",
                                    "@LongitudeNumber": "-118.281788",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "51750223",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-11-16T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "3650000.00",
                                        "@BuyerUnparsedName_ext": "API 2370 HOLDINGS LLC",
                                        "@SellerUnparsedName": "STADIUM RP DEVELOPMENT PARTNERS",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "510.48951048951",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "18.00",
                                        "@TotalBedroomCount": "18",
                                        "@TotalBathroomFullCount_ext": "18",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "1",
                                        "@LivingUnitCount": "6",
                                        "@GrossLivingAreaSquareFeetCount": "7150",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1990"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "Type Not Specified",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "CENTRAL"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "178.00",
                                        "@LotSquareFeetCount": "8875.00",
                                        "@WidthFeetCount": "50.00",
                                        "@PropertyZoningCategoryType": "LARD1.5",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "2907000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "ELLIS TRACT LOT 110",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "",
                                        "@_City": "",
                                        "@_State": "",
                                        "@_PostalCode": "",
                                    },
                                    "_OWNER": {"@_Name": "API 2370 HOLDINGS LLC,", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "11",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "12",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.67442624189",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "346 S WILTON PL",
                                    "@_State": "CA",
                                    "@_PostalCode": "90020",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.067571",
                                    "@LongitudeNumber": "-118.313712",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154628757",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-04-11T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "3950000.00",
                                        "@BuyerUnparsedName_ext": "BAE, THERESIA CHOI",
                                        "@SellerUnparsedName": "ZLH MANAGEMENT LLC",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "580.88235294118",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "14.00",
                                        "@TotalBedroomCount": "14",
                                        "@TotalBathroomFullCount_ext": "14",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "8",
                                        "@GrossLivingAreaSquareFeetCount": "6800",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1989"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "NP"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "6973.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "1232266",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "VAN NESS AVENUE SQUARE 1/2 VAC ALLEY ADJ ON E AND EX OF ST LOT 3 BLK 1",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "1357 SUGAR LOAF DR",
                                        "@_City": "LA CANADA",
                                        "@_State": "CA",
                                        "@_PostalCode": "91011",
                                    },
                                    "_OWNER": {"@_Name": "BAE THERESIA CHOI", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "12",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "13",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.69362760812",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "611 N OCCIDENTAL BLVD",
                                    "@_State": "CA",
                                    "@_PostalCode": "90026",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.07742",
                                    "@LongitudeNumber": "-118.275837",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154624377",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-01-27T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "2100000.00",
                                        "@BuyerUnparsedName_ext": "611 OCCIDENTAL LLC",
                                        "@SellerUnparsedName": "BULOSAN, HEDELIZA O",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "432.98969072165",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0000107554",
                                                    "@_Amount": "1465000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "8.00",
                                        "@TotalBedroomCount": "15",
                                        "@TotalBathroomFullCount_ext": "8",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "8",
                                        "@GrossLivingAreaSquareFeetCount": "4850",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1984"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "NP"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "142.00",
                                        "@LotSquareFeetCount": "7100.00",
                                        "@WidthFeetCount": "50.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "700321",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "WALBROOK PARK TRACT LOT 3",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "2327 FLINTRIDGE DR",
                                        "@_City": "GLENDALE",
                                        "@_State": "CA",
                                        "@_PostalCode": "91206",
                                    },
                                    "_OWNER": {"@_Name": "HEDELIZA O BULOSAN", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "13",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "14",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.73945389766",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "402 N ARDMORE AVE",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.077801",
                                    "@LongitudeNumber": "-118.302066",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154765504",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-09-02T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "0.00",
                                        "@BuyerUnparsedName_ext": "PME PROPERTIES LLC",
                                        "@SellerUnparsedName": "PEDRAM, MIKE EBRAHIMI",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "0.00",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0001352159",
                                                    "@_Amount": "948000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "10.00",
                                        "@TotalBedroomCount": "10",
                                        "@TotalBathroomFullCount_ext": "10",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "6",
                                        "@GrossLivingAreaSquareFeetCount": "4476",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1989"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {
                                            "@_TypeOtherDescription": "FL0",
                                            "@_UnitDescription": "FLOOR/WALL FURNACE",
                                        },
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "NP"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "5500.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "1994000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "LA PALOMA ADD W 110 FT OF LOT 9 BLK 19",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "6230 WILSHIRE BLVD STE # A",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90048",
                                    },
                                    "_OWNER": {"@_Name": "PME PROPERTIES LLC", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "14",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "15",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.9133349419",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "639 N JUANITA AVE",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.082892",
                                    "@LongitudeNumber": "-118.290873",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "45994067",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-12-17T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "2875000.00",
                                        "@BuyerUnparsedName_ext": "639 JUANITA AVE LLC|MFT 639 N JUANITA AVE LLC",
                                        "@SellerUnparsedName": "ROSENGARTEN, MICHAEL J",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "344.7242206235",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "18.00",
                                        "@TotalBedroomCount": "18",
                                        "@TotalBathroomFullCount_ext": "18",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "9",
                                        "@GrossLivingAreaSquareFeetCount": "8340",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1990"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "CENTRAL"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "7543.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "2875000",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "DAYTON HEIGHTS TRACT LOT 5 BLK F",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "9320 WILSHIRE BLVD STE # 208",
                                        "@_City": "BEVERLY HILLS",
                                        "@_State": "CA",
                                        "@_PostalCode": "90212",
                                    },
                                    "_OWNER": {
                                        "@_Name": "639 N JUANITA AVE LLC & MFT 639 N JUANITA AVE LLC",
                                        "@_SecondaryOwnerName_ext": "",
                                    },
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "15",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "16",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.97377900012",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "564 N ARDMORE AVE",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.08179",
                                    "@LongitudeNumber": "-118.301325",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "43873796",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-07-30T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "0.00",
                                        "@BuyerUnparsedName_ext": "564 N ARDMORE LLC",
                                        "@SellerUnparsedName": "CAMPBELL, PRISCILLA A",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "0.00",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0001176905",
                                                    "@_Amount": "1448000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "15.00",
                                        "@TotalBedroomCount": "15",
                                        "@TotalBathroomFullCount_ext": "15",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "1",
                                        "@LivingUnitCount": "9",
                                        "@GrossLivingAreaSquareFeetCount": "7126",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1990"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "Type Not Specified",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "NP"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "150.00",
                                        "@LotSquareFeetCount": "7501.00",
                                        "@WidthFeetCount": "50.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "1325016",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "ARDMORE HEIGHTS LOT 124",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "709 20TH ST",
                                        "@_City": "SANTA MONICA",
                                        "@_State": "CA",
                                        "@_PostalCode": "90402",
                                    },
                                    "_OWNER": {"@_Name": "564 N ARDMORE LLC", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "16",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "17",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.98876527991",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "827 GLENDALE BLVD",
                                    "@_State": "CA",
                                    "@_PostalCode": "90026",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.073988",
                                    "@LongitudeNumber": "-118.262115",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154738497",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-11-23T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "3150000.00",
                                        "@BuyerUnparsedName_ext": "WONG, CHRISTINA|CSC WONG FAMILY TRUST",
                                        "@SellerUnparsedName": "ECHO PARK CAPITAL VENTURE LLC",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "397.52650176678",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0001741320",
                                                    "@_Amount": "1200000",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "12.00",
                                        "@TotalBedroomCount": "10",
                                        "@TotalBathroomFullCount_ext": "12",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "5",
                                        "@GrossLivingAreaSquareFeetCount": "7924",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1988"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "CENTRAL"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "6999.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LARD2",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "3154500",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "ECHO PARK TR EX OF ST LOT 29",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "445 OXFORD DR",
                                        "@_City": "ARCADIA",
                                        "@_State": "CA",
                                        "@_PostalCode": "91007",
                                    },
                                    "_OWNER": {"@_Name": "CHRISTINA WONG", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "17",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "18",
                                    "@DistanceFromSubjectPropertyMilesCount": "1.99536685582",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "831 GLENDALE BLVD",
                                    "@_State": "CA",
                                    "@_PostalCode": "90026",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.074125",
                                    "@LongitudeNumber": "-118.262105",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154738496",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-04-19T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "2500000.00",
                                        "@BuyerUnparsedName_ext": "OPEN HOUSE INVESTMENTS LLC",
                                        "@SellerUnparsedName": "MEADORS, HELEN M",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "564.07942238267",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "5.00",
                                        "@TotalBedroomCount": "10",
                                        "@TotalBathroomFullCount_ext": "5",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "5",
                                        "@GrossLivingAreaSquareFeetCount": "4432",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1986"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "140.00",
                                        "@LotSquareFeetCount": "6999.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LARD2",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "431870",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "ECHO PARK TRACT (EX OF ST) LOT 28 N",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "250 E 1ST ST STE # 402",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90012",
                                    },
                                    "_OWNER": {
                                        "@_Name": "OPEN HOUSE INVESTMENTS LLC,",
                                        "@_SecondaryOwnerName_ext": "",
                                    },
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "18",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "19",
                                    "@DistanceFromSubjectPropertyMilesCount": "2.03259668164",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "641 N NORMANDIE AVE",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.082856",
                                    "@LongitudeNumber": "-118.300843",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154765219",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2021-09-14T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "3150000.00",
                                        "@BuyerUnparsedName_ext": "CHUNG, JACKIE J|NJC PACK LLC",
                                        "@SellerUnparsedName": "RADIX LLC",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "359.4249201278",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {"@_Type": "First", "@TrustDeedDocumentNumber": "", "@_Amount": "0"},
                                                {"@_Type": "SecondConcurrent", "@_Amount": "0"},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "16.00",
                                        "@TotalBedroomCount": "16",
                                        "@TotalBathroomFullCount_ext": "16",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "9",
                                        "@GrossLivingAreaSquareFeetCount": "8764",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1990"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "7252.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "3150800",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "ARDMORE HEIGHTS EX OF ST LOT 95",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "13020 PACIFIC PROMENADE UNIT # 405",
                                        "@_City": "PLAYA VISTA",
                                        "@_State": "CA",
                                        "@_PostalCode": "90094",
                                    },
                                    "_OWNER": {"@_Name": "NORMANDIE 641 LLC,", "@_SecondaryOwnerName_ext": ""},
                                },
                            },
                            {
                                "PRODUCT_INFO_ext": {
                                    "@ReportID_ext": "104",
                                    "@ReportDescription_ext": "SalesComparables",
                                    "@Product_ext": "SalesCompProperties",
                                    "@RecordNumber_ext": "19",
                                    "@MappingVersion_ext": "1",
                                },
                                "COMPARABLE_PROPERTY_ext": {
                                    "@_Sequence": "20",
                                    "@DistanceFromSubjectPropertyMilesCount": "2.05154669109",
                                    "@_City": "LOS ANGELES",
                                    "@_StreetAddress": "626 N KINGSLEY DR",
                                    "@_State": "CA",
                                    "@_PostalCode": "90004",
                                    "@StandardUseCode_ext": "RAPT",
                                    "@StandardUseDescription_ext": "Apartment",
                                    "@SiteMailAddressSameIndicator_ext": "",
                                    "@LatitudeNumber": "34.082464",
                                    "@LongitudeNumber": "-118.302898",
                                    "_IDENTIFICATION": {
                                        "@RTPropertyID_ext": "154765430",
                                        "@CountyFIPSName_ext": "Los Angeles",
                                        "@AssessorsSecondParcelIdentifier": "",
                                        "@DQPropertyID_ext": "",
                                    },
                                    "SALES_HISTORY": {
                                        "@TransferDate_ext": "2022-11-18T00:00:00",
                                        "@FullOrPartialTransferValueType_ext": "",
                                        "@PropertySalesAmount": "2813500.00",
                                        "@BuyerUnparsedName_ext": "NORTH KINGSLEY APARTMENTS LLC",
                                        "@SellerUnparsedName": "SAR, GLORIA SCOTT",
                                        "@MultipleApnIndicator_ext": "",
                                        "@ArmsLengthTransactionIndicatorExt": "A",
                                        "@PricePerSquareFootAmount": "427.84367396594",
                                        "LOANS_ext": {
                                            "LOAN_ext": [
                                                {
                                                    "@_Type": "First",
                                                    "@TrustDeedDocumentNumber": "0001090422",
                                                    "@_Amount": "4501875",
                                                },
                                                {"@_Type": "SecondConcurrent", "@_Amount": ""},
                                                {"@_Type": "ThirdConcurrent", "@_Amount": ""},
                                            ]
                                        },
                                        "LOAN_ext": {"@SellerCarrybackindicator": ""},
                                    },
                                    "STRUCTURE": {
                                        "@TotalBathroomCount": "10.00",
                                        "@TotalBedroomCount": "18",
                                        "@TotalBathroomFullCount_ext": "10",
                                        "@TotalBathroomHalfCount_ext": "",
                                        "@TotalBathroomQuarterCount_ext": "",
                                        "@TotalBathroomThreeQuarterCount_ext": "",
                                        "@TotalRoomCount": "0",
                                        "@StoriesCount": "0",
                                        "@LivingUnitCount": "10",
                                        "@GrossLivingAreaSquareFeetCount": "6576",
                                        "@TotalBathroomCountDq_ext": "",
                                        "STRUCTURE_ANALYSIS": {"@PropertyStructureBuiltYear": "1987"},
                                        "CAR_STORAGE": {
                                            "CAR_STORAGE_LOCATION": {
                                                "@SquareFeetCount": "0",
                                                "@_ParkingSpacesCount": "",
                                                "@_Type": "",
                                                "@_TypeOtherDescription": "NOT PROVIDED",
                                            }
                                        },
                                        "ATTIC": {"@SquareFeetCount": "0"},
                                        "BASEMENT": {"@SquareFeetCount": "0", "@_FinishedPercent": "0.00"},
                                        "AMENITIES": {
                                            "AMENITY": [
                                                {"@_Type": "Pool", "@_ExistsIndicator": ""},
                                                {"@_Type": "Fireplace", "@_DetailedDescription": ""},
                                            ]
                                        },
                                        "EXTERIOR_FEATURE": {
                                            "@_Type": "Other",
                                            "@_TypeOtherDescription": "RoofMaterial",
                                            "@_Description": "Unknown or Not Provided",
                                        },
                                        "HEATING": {"@_TypeOtherDescription": "000", "@_UnitDescription": "NONE"},
                                        "LEVELS": {
                                            "LEVEL": [
                                                {"@_Type": "LevelOne", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelTwo", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelThree", "@SquareFeetCount": "0"},
                                                {"@_Type": "LevelFour", "@SquareFeetCount": "0"},
                                            ]
                                        },
                                        "COOLING": {"@_UnitDescription": "YES"},
                                    },
                                    "SITE": {
                                        "@DepthFeetCount": "0.00",
                                        "@LotSquareFeetCount": "11634.00",
                                        "@WidthFeetCount": "0.00",
                                        "@PropertyZoningCategoryType": "LAR3",
                                    },
                                    "_TAX": {
                                        "@_AssessorFullCashValue_ext": "",
                                        "@_AssessorMarketValue_ext": "0",
                                        "@_TotalAssessedValueAmount": "713980",
                                    },
                                    "_LEGAL_DESCRIPTION": {
                                        "@_Type": "Other",
                                        "@_TextDescription": "UNEEDA PLACE*(EX OF ST) LOT 3",
                                    },
                                    "MAILING_ADDRESS_ext": {
                                        "@_StreetAddress": "11340 W OLYMPIC BLVD STE # 160",
                                        "@_City": "LOS ANGELES",
                                        "@_State": "CA",
                                        "@_PostalCode": "90064",
                                    },
                                    "_OWNER": {
                                        "@_Name": "NORTH KINGSLEY APARTMENTS LLC,",
                                        "@_SecondaryOwnerName_ext": "",
                                    },
                                },
                            },
                        ]
                    }
                }
            },
        },
        "PRODUCT": {
            "STATUS": {
                "@_Code": "0",
                "@_Condition": "Success",
                "@_Name": "Success",
                "@_Description": "Successful execution",
            }
        },
        "ECHOED_FIELDS_ext": {
            "@JobID": "",
            "@LoanNumber": "",
            "@PreparedBy": "",
            "@ResellerID": "",
            "@PreparedFor": "",
        },
    }
}
